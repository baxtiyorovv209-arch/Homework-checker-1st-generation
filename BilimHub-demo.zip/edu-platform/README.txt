BilimHub — Uzbek educational platform prototype

START
1. Extract the ZIP archive.
2. Open index.html in a modern browser (Chrome, Edge, Firefox).
3. Choose Ustoz kabineti or O‘quvchi kabineti.
4. DEMO teacher invitation code: Muhammadali
5. Students must enter full name and at least one contact method.

WHAT WORKS IN THIS PROTOTYPE
- Uzbek Latin interface and responsive desktop/mobile layout.
- Separate teacher and student demo flows.
- Assignment creation with odd/even/all exercise number generation.
- Student assignment workflow, photo preview/upload, per-exercise self-reported status, sequential photo requirement, review and final submit.
- Teacher dashboard, assignment progress, student table, search, CSV export, student profile, submission review, comments, notifications.
- Demo data persists in this browser using localStorage.

IMPORTANT SECURITY / PRODUCTION LIMITATIONS
This is a browser-only prototype, NOT a production-secure full-stack application. The invitation code is checked in frontend JavaScript, and localStorage data can be changed or viewed by the person using the browser. Do not use real student contact details or private homework photos in this demo. Photos are stored as browser data URLs and can exceed browser storage limits. No real multi-device sync, server-side authentication, database, OTP verification, private object storage, or server notifications are configured.

For production deployment, connect a backend such as Supabase: implement Supabase Auth, server-side invitation-code verification (store only a hash/secret in server environment), PostgreSQL tables, Row Level Security policies, private Storage bucket with strict MIME/size validation, role-protected routes, and real-time updates. Never put service-role keys in frontend code.
